
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CalendarIcon, ExternalLink, Filter, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';

interface NewsArticle {
  id: number;
  title: string;
  summary: string;
  date: Date;
  source: string;
  url: string;
  category: string;
  region?: string;
  isPriority: boolean;
}

const WHOHeadlinesPage: React.FC = () => {
  const [newsArticles] = useState<NewsArticle[]>([
    {
      id: 1,
      title: 'WHO releases guidelines on mental health at work',
      summary: 'New guidelines on mental health at work have been released today by the World Health Organization and the International Labour Organization to address the substantial adverse impacts of mental health risks and conditions in the workplace.',
      date: new Date('2023-06-15'),
      source: 'World Health Organization',
      url: '#',
      category: 'Mental Health',
      region: 'Global',
      isPriority: true
    },
    {
      id: 2,
      title: 'WHO announces new initiative to accelerate elimination of cervical cancer',
      summary: 'The World Health Organization (WHO) has announced a new global initiative to accelerate the elimination of cervical cancer as a public health problem. The initiative aims to strengthen prevention and treatment services in countries with the highest burden of the disease.',
      date: new Date('2023-07-02'),
      source: 'World Health Organization',
      url: '#',
      category: 'Cancer',
      region: 'Global',
      isPriority: true
    },
    {
      id: 3,
      title: 'COVID-19 pandemic triggers 25% increase in prevalence of anxiety and depression worldwide',
      summary: 'In the first year of the COVID-19 pandemic, global prevalence of anxiety and depression increased by a massive 25%, according to a scientific brief released by the World Health Organization (WHO) today.',
      date: new Date('2023-05-18'),
      source: 'World Health Organization',
      url: '#',
      category: 'COVID-19',
      region: 'Global',
      isPriority: false
    },
    {
      id: 4,
      title: 'WHO recommends groundbreaking malaria vaccine for children at risk',
      summary: 'The World Health Organization (WHO) is recommending widespread use of the RTS,S/AS01 (RTS,S) malaria vaccine among children in sub-Saharan Africa and in other regions with moderate to high P. falciparum malaria transmission.',
      date: new Date('2023-06-29'),
      source: 'World Health Organization',
      url: '#',
      category: 'Vaccines',
      region: 'Africa',
      isPriority: true
    },
    {
      id: 5,
      title: 'WHO updates guidelines for air quality to prevent millions of deaths',
      summary: 'The World Health Organization (WHO) has updated its global air quality guidelines, recommending new air quality levels to protect the health of populations. The last WHO update was in 2005.',
      date: new Date('2023-06-10'),
      source: 'World Health Organization',
      url: '#',
      category: 'Environment',
      region: 'Global',
      isPriority: false
    },
    {
      id: 6,
      title: 'WHO and partners call for urgent action on meningitis',
      summary: 'In a year when COVID-19 threatens to derail decades of progress against preventable diseases, the World Health Organization (WHO) and partners launched a new strategy to defeat meningitis by 2030.',
      date: new Date('2023-07-11'),
      source: 'World Health Organization',
      url: '#',
      category: 'Infectious Diseases',
      region: 'Global',
      isPriority: false
    },
    {
      id: 7,
      title: 'WHO announces winners of global innovation challenge on infection prevention and control',
      summary: 'The World Health Organization (WHO) has announced the winners of a global innovation challenge for new solutions to prevent and manage infections in health care.',
      date: new Date('2023-06-25'),
      source: 'World Health Organization',
      url: '#',
      category: 'Health Systems',
      region: 'Global',
      isPriority: false
    },
  ]);
  
  const categories = ['All', 'COVID-19', 'Mental Health', 'Cancer', 'Vaccines', 'Environment', 'Infectious Diseases', 'Health Systems'];
  const [activeCategory, setActiveCategory] = useState('All');
  
  const filteredArticles = activeCategory === 'All' 
    ? newsArticles 
    : newsArticles.filter(article => article.category === activeCategory);
  
  const priorityArticles = newsArticles.filter(article => article.isPriority);

  return (
    <Layout>
      <div className="space-y-8 max-w-5xl mx-auto">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">WHO Headlines</h1>
          <p className="text-muted-foreground">
            Stay updated with the latest health news and advisories from the World Health Organization.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-3">
            <Card className="bg-medical-50 border-medical-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg text-medical-800">Priority Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {priorityArticles.slice(0, 3).map((article) => (
                    <Card key={article.id} className="border-none shadow-sm hover:shadow transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <Badge className="bg-medical-600 hover:bg-medical-700">{article.category}</Badge>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <CalendarIcon size={12} className="mr-1" />
                            {format(article.date, 'MMM d, yyyy')}
                          </div>
                        </div>
                        <CardTitle className="text-base mt-2">{article.title}</CardTitle>
                      </CardHeader>
                      <CardFooter className="pt-0">
                        <Button variant="link" className="p-0 h-auto text-medical-600 hover:text-medical-800">
                          Read more <ExternalLink size={12} className="ml-1" />
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-4 md:space-y-0">
              <div className="space-y-1">
                <h2 className="text-xl font-semibold">Latest Headlines</h2>
                <p className="text-sm text-muted-foreground">Browse the latest health news from around the world</p>
              </div>
              
              <div className="flex items-center space-x-2 self-start">
                <Button variant="outline" size="sm" className="h-9">
                  <Filter size={14} className="mr-1" />
                  Filter
                </Button>
                <Button variant="outline" size="sm" className="h-9">
                  <RefreshCw size={14} className="mr-1" />
                  Refresh
                </Button>
              </div>
            </div>
            
            <Tabs defaultValue="All" onValueChange={setActiveCategory}>
              <TabsList className="mb-4 flex flex-wrap h-auto">
                {categories.map(category => (
                  <TabsTrigger key={category} value={category} className="mb-1">
                    {category}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              <TabsContent value={activeCategory} className="mt-0">
                <div className="space-y-4">
                  {filteredArticles.map((article) => (
                    <Card key={article.id} className="overflow-hidden">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-3/4 p-6">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">{article.category}</Badge>
                            {article.region && (
                              <Badge variant="secondary">{article.region}</Badge>
                            )}
                          </div>
                          
                          <CardTitle className="mb-2">{article.title}</CardTitle>
                          <CardDescription className="text-base mb-4">
                            {article.summary}
                          </CardDescription>
                          
                          <div className="flex items-center justify-between mt-4">
                            <div className="flex items-center text-xs text-muted-foreground">
                              <CalendarIcon size={12} className="mr-1" />
                              {format(article.date, 'MMMM d, yyyy')}
                            </div>
                            <Button variant="link" className="p-0 h-auto text-medical-600 hover:text-medical-800">
                              Read full article <ExternalLink size={12} className="ml-1" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="md:w-1/4 bg-medical-50 flex flex-col justify-center items-center p-6 border-t md:border-t-0 md:border-l">
                          <div className="text-center">
                            <p className="text-sm font-medium">Source</p>
                            <p className="text-sm text-muted-foreground">{article.source}</p>
                            
                            <Separator className="my-4" />
                            
                            <Button variant="outline" size="sm" className="mt-2 w-full">
                              Share
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default WHOHeadlinesPage;
