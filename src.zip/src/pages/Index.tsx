
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Layout from '@/components/Layout';
import { Heart, AlertCircle, Search, MessageSquare } from 'lucide-react';

const Index: React.FC = () => {
  const features = [
    {
      title: 'Chat with GyattGPT',
      description: 'Ask any health-related questions and get accurate information instantly.',
      icon: MessageSquare,
      link: '/chat',
    },
    {
      title: 'Personal Risk Assessment',
      description: 'Upload your medical records or input your health data for personalized risk analysis.',
      icon: Heart,
      link: '/risk-assessment',
    },
    {
      title: 'Disease Information',
      description: 'Search for information about specific diseases, symptoms, and treatments.',
      icon: Search,
      link: '/disease-info',
    },
    {
      title: 'WHO Headlines',
      description: 'Stay updated with the latest health news and advisories from the World Health Organization.',
      icon: AlertCircle,
      link: '/who-headlines',
    },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <section className="text-center py-12 space-y-4 animate-fadeIn">
          <h1 className="text-4xl md:text-6xl font-bold text-medical-800">
            Welcome to <span className="bg-clip-text text-transparent bg-gradient-to-r from-medical-700 to-medical-500">GyattGPT</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your personal AI health assistant that helps you understand your health risks and take preventive measures.
          </p>
          <div className="pt-6">
            <Link to="/chat">
              <Button size="lg" className="bg-medical-600 hover:bg-medical-700">
                Start Chatting
              </Button>
            </Link>
          </div>
        </section>

        <section className="py-8">
          <h2 className="text-3xl font-semibold mb-8">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center gap-4">
                  <div className="bg-medical-100 p-3 rounded-full">
                    <feature.icon className="text-medical-600" size={24} />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base mb-4">{feature.description}</CardDescription>
                  <Link to={feature.link}>
                    <Button variant="outline" className="w-full border-medical-300 text-medical-700 hover:bg-medical-50">
                      Explore
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="py-8 bg-medical-50 -mx-6 px-6 rounded-lg">
          <div className="max-w-4xl mx-auto text-center space-y-4">
            <h2 className="text-3xl font-semibold">About GyattGPT</h2>
            <p className="text-lg text-gray-700">
              GyattGPT uses advanced AI to analyze health records and provide personalized health insights. 
              Our system can help identify diseases you may be at risk for (over 70% probability) and suggest 
              preventive measures to reduce your risk. We also provide up-to-date information on various diseases 
              and health conditions from reliable sources.
            </p>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Index;
