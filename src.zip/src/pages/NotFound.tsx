
import React from "react";
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

const NotFound = () => {
  const location = useLocation();

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-[70vh] text-center space-y-6">
        <div className="space-y-2">
          <h1 className="text-6xl font-bold text-medical-700">404</h1>
          <p className="text-2xl font-medium">Page not found</p>
        </div>
        
        <p className="text-muted-foreground max-w-md">
          Sorry, we couldn't find the page you were looking for at {location.pathname}
        </p>
        
        <div className="pt-6">
          <Link to="/">
            <Button size="lg" className="bg-medical-600 hover:bg-medical-700">
              Return to Home
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default NotFound;
