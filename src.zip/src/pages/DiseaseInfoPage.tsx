import React, { useState } from 'react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, CircleAlert, ExternalLink, Loader2 } from 'lucide-react';

interface Disease {
  id: number;
  name: string;
  description: string;
  symptoms: string[];
  causes: string[];
  riskFactors: string[];
  preventions: string[];
  treatments: string[];
}

interface WikipediaResult {
  name: string;
  description: string;
  extract: string;
  url: string;
}

interface Category {
  id: number;
  name: string;
  diseases: string[];
}

const DiseaseInfoPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDisease, setActiveDisease] = useState<Disease | null>(null);
  const [wikipediaResult, setWikipediaResult] = useState<WikipediaResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const categories: Category[] = [
    { id: 1, name: 'Cardiovascular', diseases: ['Hypertension', 'Coronary Heart Disease', 'Stroke'] },
    { id: 2, name: 'Metabolic', diseases: ['Type 2 Diabetes', 'Obesity', 'Metabolic Syndrome'] },
    { id: 3, name: 'Respiratory', diseases: ['Asthma', 'COPD', 'Sleep Apnea'] },
    { id: 4, name: 'Mental Health', diseases: ['Depression', 'Anxiety Disorders', 'Bipolar Disorder'] },
  ];
  
  const diseases: Disease[] = [
    {
      id: 1,
      name: 'Type 2 Diabetes',
      description: "Type 2 diabetes is a chronic condition that affects the way the body processes blood sugar (glucose). With type 2 diabetes, the body either doesn't produce enough insulin, or it resists insulin.",
      symptoms: [
        'Increased thirst and frequent urination',
        'Increased hunger',
        'Fatigue',
        'Blurred vision',
        'Slow-healing sores',
        'Frequent infections',
        'Weight loss',
        'Areas of darkened skin'
      ],
      causes: [
        'Overweight and obesity',
        'Insulin resistance',
        'Genetic factors',
        'Environmental factors'
      ],
      riskFactors: [
        'Being overweight or obese',
        'Fat distribution (abdominal fat)',
        'Inactivity',
        'Family history',
        'Age (risk increases as you get older)',
        'Prediabetes',
        'Gestational diabetes'
      ],
      preventions: [
        'Eating healthy foods',
        'Getting active',
        'Losing weight',
        'Regular health screenings',
        'Managing blood pressure and cholesterol',
        'Avoiding smoking and excessive alcohol consumption'
      ],
      treatments: [
        'Healthy eating and regular physical activity',
        'Weight loss',
        'Blood sugar monitoring',
        'Diabetes medications or insulin therapy',
        'Regular checkups with healthcare providers'
      ]
    },
    {
      id: 2,
      name: 'Hypertension',
      description: "Hypertension, or high blood pressure, is a common condition in which the long-term force of the blood against your artery walls is high enough that it may eventually cause health problems, such as heart disease.",
      symptoms: [
        'Most people have no symptoms, even if blood pressure readings reach dangerously high levels',
        'Some people may experience headaches',
        'Shortness of breath',
        'Nosebleeds'
      ],
      causes: [
        'Primary hypertension (no identifiable cause)',
        'Secondary hypertension (caused by underlying conditions)',
        'Kidney disease',
        'Adrenal gland tumors',
        'Thyroid problems',
        'Certain medications',
        'Illegal drugs'
      ],
      riskFactors: [
        'Age (risk increases as you get older)',
        'Family history',
        'Being overweight or obese',
        'Not being physically active',
        'Using tobacco',
        'Too much salt (sodium) in your diet',
        'Too little potassium in your diet',
        'Stress',
        'Certain chronic conditions'
      ],
      preventions: [
        'Decreasing salt intake',
        'Regular exercise',
        'Maintaining a healthy weight',
        'Limiting alcohol consumption',
        'Quitting smoking',
        'Managing stress',
        'Regular monitoring of blood pressure'
      ],
      treatments: [
        'Lifestyle changes',
        'Diuretics',
        'ACE inhibitors',
        'Angiotensin II receptor blockers',
        'Calcium channel blockers',
        'Beta blockers',
        'Regular monitoring and follow-up with healthcare providers'
      ]
    },
    {
      id: 3,
      name: 'Coronary Heart Disease',
      description: "Coronary heart disease is a type of heart disease that develops when the arteries of the heart cannot deliver enough oxygen-rich blood to the heart. It is the leading cause of death in the United States.",
      symptoms: [
        'Chest pain (angina)',
        'Shortness of breath',
        'Pain in the neck, jaw, throat, upper abdomen, or back',
        'Heart attack'
      ],
      causes: [
        'Atherosclerosis (build-up of plaque in the arteries)',
        'Damage to the inner lining of coronary arteries',
        'Inflammation',
        'Blood clots'
      ],
      riskFactors: [
        'Age',
        'Sex (men are generally at greater risk)',
        'Family history',
        'Smoking',
        'High blood pressure',
        'High blood cholesterol levels',
        'Diabetes',
        'Overweight or obesity',
        'Lack of physical activity',
        'Stress',
        'Unhealthy diet'
      ],
      preventions: [
        'Quit smoking',
        'Control other health conditions',
        'Exercise regularly',
        'Eat a heart-healthy diet',
        'Maintain a healthy weight',
        'Reduce and manage stress',
        'Regular check-ups with healthcare providers'
      ],
      treatments: [
        'Lifestyle changes',
        'Medications (statins, beta blockers, nitrates, etc.)',
        'Medical procedures (angioplasty, stent placement)',
        'Coronary artery bypass surgery',
        'Cardiac rehabilitation'
      ]
    }
  ];
  
  const fetchWikipediaData = async (query: string) => {
    setIsLoading(true);
    setError(null);
    setWikipediaResult(null);
    
    try {
      // Encode the search query for the URL
      const encodedQuery = encodeURIComponent(query);
      
      // Fetch from Wikipedia API
      const response = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodedQuery}`
      );
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Disease information not found on Wikipedia.");
        }
        throw new Error("An error occurred while fetching from Wikipedia.");
      }
      
      const data = await response.json();
      
      // Check if it's a disambiguation page
      if (data.type === "disambiguation") {
        throw new Error("Multiple results found. Please be more specific with your search.");
      }
      
      const result: WikipediaResult = {
        name: data.title,
        description: data.description || "No description available",
        extract: data.extract || "No detailed information available",
        url: data.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${encodedQuery}`
      };
      
      setWikipediaResult(result);
    } catch (err) {
      console.error("Wikipedia fetch error:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) return;
    
    // First check our local database
    const foundDisease = diseases.find(
      disease => disease.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    if (foundDisease) {
      setActiveDisease(foundDisease);
      setWikipediaResult(null);
    } else {
      // If not found locally, try Wikipedia
      setActiveDisease(null);
      await fetchWikipediaData(searchQuery);
    }
  };
  
  const handleDiseaseClick = (diseaseName: string) => {
    const foundDisease = diseases.find(
      disease => disease.name === diseaseName
    );
    
    if (foundDisease) {
      setActiveDisease(foundDisease);
      setSearchQuery(foundDisease.name);
      setWikipediaResult(null);
    }
  };

  return (
    <Layout>
      <div className="space-y-8 max-w-5xl mx-auto">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Disease Information</h1>
          <p className="text-muted-foreground">
            Search for detailed information about diseases, their symptoms, causes, risk factors, and treatments.
          </p>
        </div>
        
        <form onSubmit={handleSearch} className="flex gap-2">
          <Input
            type="text"
            placeholder="Search for a disease..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" className="bg-medical-600 hover:bg-medical-700" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 size={18} className="mr-2 animate-spin" />
                Searching...
              </>
            ) : (
              <>
                <Search size={18} className="mr-2" />
                Search
              </>
            )}
          </Button>
        </form>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-6 md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Disease Categories</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                {categories.map((category) => (
                  <div key={category.id} className="mb-4">
                    <h3 className="font-medium text-sm text-muted-foreground mb-2">{category.name}</h3>
                    <ul className="space-y-1">
                      {category.diseases.map((disease, index) => (
                        <li key={index}>
                          <Button
                            variant="ghost"
                            className={`w-full justify-start px-2 ${activeDisease?.name === disease ? 'bg-medical-50 text-medical-800' : ''}`}
                            onClick={() => handleDiseaseClick(disease)}
                          >
                            {disease}
                          </Button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-3">
            {activeDisease ? (
              // Display local disease information
              <div className="space-y-6 animate-fadeIn">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">{activeDisease.name}</CardTitle>
                    <CardDescription className="text-base">
                      {activeDisease.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <Tabs defaultValue="symptoms">
                      <TabsList className="grid grid-cols-5 w-full">
                        <TabsTrigger value="symptoms">Symptoms</TabsTrigger>
                        <TabsTrigger value="causes">Causes</TabsTrigger>
                        <TabsTrigger value="risk">Risk Factors</TabsTrigger>
                        <TabsTrigger value="prevention">Prevention</TabsTrigger>
                        <TabsTrigger value="treatment">Treatment</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="symptoms" className="pt-4">
                        <ul className="space-y-2">
                          {activeDisease.symptoms.map((symptom, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="rounded-full bg-medical-100 w-1.5 h-1.5 mt-2"></div>
                              <span>{symptom}</span>
                            </li>
                          ))}
                        </ul>
                      </TabsContent>
                      
                      <TabsContent value="causes" className="pt-4">
                        <ul className="space-y-2">
                          {activeDisease.causes.map((cause, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="rounded-full bg-medical-100 w-1.5 h-1.5 mt-2"></div>
                              <span>{cause}</span>
                            </li>
                          ))}
                        </ul>
                      </TabsContent>
                      
                      <TabsContent value="risk" className="pt-4">
                        <ul className="space-y-2">
                          {activeDisease.riskFactors.map((factor, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="rounded-full bg-medical-100 w-1.5 h-1.5 mt-2"></div>
                              <span>{factor}</span>
                            </li>
                          ))}
                        </ul>
                      </TabsContent>
                      
                      <TabsContent value="prevention" className="pt-4">
                        <ul className="space-y-2">
                          {activeDisease.preventions.map((prevention, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="rounded-full bg-medical-100 w-1.5 h-1.5 mt-2"></div>
                              <span>{prevention}</span>
                            </li>
                          ))}
                        </ul>
                      </TabsContent>
                      
                      <TabsContent value="treatment" className="pt-4">
                        <ul className="space-y-2">
                          {activeDisease.treatments.map((treatment, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <div className="rounded-full bg-medical-100 w-1.5 h-1.5 mt-2"></div>
                              <span>{treatment}</span>
                            </li>
                          ))}
                        </ul>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Medical Disclaimer</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-start gap-3">
                      <CircleAlert className="text-amber-500 flex-shrink-0 mt-1" size={18} />
                      <p className="text-sm text-muted-foreground">
                        The information provided is for educational purposes only and is not a substitute 
                        for professional medical advice, diagnosis, or treatment. Always seek the advice 
                        of your physician or other qualified health provider with any questions you may 
                        have regarding a medical condition.
                      </p>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="flex justify-end">
                  <Button variant="outline" className="text-sm flex items-center gap-2">
                    Learn more from trusted sources
                    <ExternalLink size={14} />
                  </Button>
                </div>
              </div>
            ) : wikipediaResult ? (
              // Display Wikipedia data when found
              <div className="space-y-6 animate-fadeIn">
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-2xl">{wikipediaResult.name}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">Source: Wikipedia</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs flex items-center gap-1"
                        onClick={() => window.open(wikipediaResult.url, '_blank')}
                      >
                        View on Wikipedia
                        <ExternalLink size={12} />
                      </Button>
                    </div>
                    <CardDescription className="text-base mt-4">
                      {wikipediaResult.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="prose prose-slate max-w-none">
                      <p>{wikipediaResult.extract}</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Information Notice</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-start gap-3">
                      <CircleAlert className="text-amber-500 flex-shrink-0 mt-1" size={18} />
                      <div className="text-sm text-muted-foreground">
                        <p className="mb-2">
                          This information is sourced from Wikipedia and may not be complete or medically verified.
                        </p>
                        <p>
                          The information provided is for educational purposes only and is not a substitute 
                          for professional medical advice, diagnosis, or treatment. Always consult with a qualified healthcare provider 
                          for medical guidance.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : isLoading ? (
              // Loading state
              <Card className="p-6 text-center">
                <div className="py-16 flex flex-col items-center justify-center gap-4">
                  <Loader2 className="h-12 w-12 animate-spin text-medical-600" />
                  <p className="text-lg font-medium text-muted-foreground">
                    Searching for information...
                  </p>
                </div>
              </Card>
            ) : error ? (
              // Error state
              <Card className="p-6 text-center border-red-200">
                <div className="py-8 space-y-2">
                  <CircleAlert className="mx-auto text-red-500" size={48} />
                  <h3 className="text-xl font-medium mt-4">Information Not Found</h3>
                  <p className="text-muted-foreground">
                    {error}
                  </p>
                  <p className="text-sm text-muted-foreground mt-4">
                    Try using different keywords or check the spelling of your search term.
                  </p>
                </div>
              </Card>
            ) : searchQuery ? (
              // No results state - this should rarely happen now with Wikipedia fallback
              <Card className="p-6 text-center">
                <div className="py-8 space-y-2">
                  <CircleAlert className="mx-auto text-amber-500" size={48} />
                  <h3 className="text-xl font-medium mt-4">Disease Not Found</h3>
                  <p className="text-muted-foreground">
                    We couldn't find information about "{searchQuery}". Please try another search term
                    or browse the categories on the left.
                  </p>
                </div>
              </Card>
            ) : (
              // Initial state
              <Card className="p-6">
                <div className="py-8 text-center space-y-2">
                  <Search className="mx-auto text-gray-400" size={48} />
                  <h3 className="text-xl font-medium mt-4">Search for a Disease</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Enter a disease name in the search box above, or browse the categories 
                    on the left to get detailed information. If we don't have information locally,
                    we'll search Wikipedia for you.
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default DiseaseInfoPage;
