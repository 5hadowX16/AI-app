import React, { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { AlertCircle, FilePlus, FileUp, Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { analyzeHealthRisk, RiskAssessmentResult } from '@/utils/claudeRiskAssessment';

interface RiskFactor {
  id: number;
  name: string;
  description: string;
  value: number;
}

interface RiskResult {
  id: number;
  disease: string;
  probability: number;
  measures: string[];
  severity: 'high' | 'medium' | 'low';
}

const RiskAssessmentPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('manual');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [familyHistory, setFamilyHistory] = useState(false);
  const [smoking, setSmoking] = useState(false);
  const [exerciseLevel, setExerciseLevel] = useState([3]); // 1-5 scale
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [fileSelected, setFileSelected] = useState(false);
  const [fileName, setFileName] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [assessmentResult, setAssessmentResult] = useState<RiskAssessmentResult | null>(null);
  const { toast } = useToast();
  
  const [riskFactors] = useState<RiskFactor[]>([
    { id: 1, name: 'Age', description: 'Age is a significant factor in many health conditions', value: 45 },
    { id: 2, name: 'BMI', description: 'Body Mass Index calculation from height and weight', value: 28 },
    { id: 3, name: 'Family History', description: 'Genetic predispositions to certain conditions', value: 35 },
    { id: 4, name: 'Lifestyle', description: 'Smoking, activity level, and other behavior factors', value: 60 },
  ]);

  const [riskResults] = useState<RiskResult[]>([
    {
      id: 1,
      disease: 'Type 2 Diabetes',
      probability: 75,
      severity: 'high',
      measures: [
        'Maintain a healthy weight through diet and exercise',
        'Reduce sugar and refined carbohydrate intake',
        'Increase physical activity to at least 150 minutes per week',
        'Regular blood sugar monitoring',
      ],
    },
    {
      id: 2,
      disease: 'Hypertension',
      probability: 82,
      severity: 'high',
      measures: [
        'Reduce sodium intake to less than 2,300mg per day',
        'Regular exercise and maintaining healthy weight',
        'Limit alcohol consumption',
        'Regular blood pressure monitoring',
      ],
    },
    {
      id: 3,
      disease: 'Coronary Heart Disease',
      probability: 71,
      severity: 'medium',
      measures: [
        'Maintain healthy cholesterol levels through diet and medication if prescribed',
        'Regular cardiovascular exercise',
        'Avoid smoking and second-hand smoke exposure',
        'Manage stress through meditation or other relaxation techniques',
      ],
    },
  ]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileSelected(true);
      setFileName(e.target.files[0].name);
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!age || !height || !weight) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);
    
    try {
      const healthData = {
        age,
        height,
        weight,
        familyHistory,
        smoking,
        exerciseLevel: exerciseLevel[0]
      };

      console.log("Analyzing health data:", healthData);
      const result = await analyzeHealthRisk(healthData);
      console.log("Assessment result:", result);
      
      setAssessmentResult(result);
      setFormSubmitted(true);
      
      toast({
        title: "Analysis Complete",
        description: "Your health risk assessment has been completed.",
      });
    } catch (error) {
      console.error("Error during analysis:", error);
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze your health data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (fileSelected) {
      setFormSubmitted(true);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-orange-100 text-orange-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateBMI = () => {
    if (height && weight) {
      const heightInMeters = parseInt(height) / 100;
      const weightInKg = parseInt(weight);
      return (weightInKg / (heightInMeters * heightInMeters)).toFixed(1);
    }
    return null;
  };

  return (
    <Layout>
      <div className="space-y-8 max-w-5xl mx-auto">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Personal Risk Assessment</h1>
          <p className="text-muted-foreground">
            Analyze your health data to identify potential health risks and receive personalized prevention recommendations.
          </p>
        </div>

        {!formSubmitted ? (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="manual">Manual Input</TabsTrigger>
              <TabsTrigger value="upload">Upload Records</TabsTrigger>
            </TabsList>
            
            <TabsContent value="manual" className="space-y-4 pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Enter Your Health Information</CardTitle>
                  <CardDescription>
                    Provide accurate information to get the best risk assessment results powered by AI analysis.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleManualSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="age">Age *</Label>
                        <Input 
                          id="age" 
                          type="number" 
                          placeholder="Years" 
                          value={age}
                          onChange={(e) => setAge(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="height">Height *</Label>
                        <Input 
                          id="height" 
                          placeholder="cm" 
                          type="number"
                          value={height}
                          onChange={(e) => setHeight(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weight">Weight *</Label>
                        <Input 
                          id="weight" 
                          placeholder="kg" 
                          type="number"
                          value={weight}
                          onChange={(e) => setWeight(e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    {calculateBMI() && (
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <p className="text-sm text-blue-800">
                          <strong>BMI:</strong> {calculateBMI()} kg/m²
                        </p>
                      </div>
                    )}

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="family-history">Family History of Chronic Diseases</Label>
                          <p className="text-sm text-muted-foreground">
                            Diabetes, heart disease, cancer, etc.
                          </p>
                        </div>
                        <Switch 
                          id="family-history"
                          checked={familyHistory}
                          onCheckedChange={setFamilyHistory}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label htmlFor="smoking">Smoking</Label>
                          <p className="text-sm text-muted-foreground">
                            Current or former smoker
                          </p>
                        </div>
                        <Switch 
                          id="smoking"
                          checked={smoking}
                          onCheckedChange={setSmoking}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="exercise">Physical Activity Level</Label>
                          <span className="text-sm text-muted-foreground">{exerciseLevel[0]}/5</span>
                        </div>
                        <Slider
                          id="exercise"
                          defaultValue={[3]}
                          max={5}
                          min={1}
                          step={1}
                          value={exerciseLevel}
                          onValueChange={setExerciseLevel}
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Sedentary</span>
                          <span>Very Active</span>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-medical-600 hover:bg-medical-700"
                      disabled={isAnalyzing}
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 size={18} className="mr-2 animate-spin" />
                          Analyzing Your Risk...
                        </>
                      ) : (
                        "Analyze My Risk"
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="upload" className="space-y-4 pt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Upload Medical Records</CardTitle>
                  <CardDescription>
                    Upload your medical records for a more comprehensive risk assessment.
                    We support PDF and FHIR formatted files.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleFileSubmit} className="space-y-6">
                    <div className="grid w-full items-center gap-4">
                      <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-12 cursor-pointer hover:bg-gray-50 transition-colors">
                        <input
                          type="file"
                          id="file-upload"
                          className="hidden"
                          accept=".pdf,.json,.xml"
                          onChange={handleFileChange}
                        />
                        <label htmlFor="file-upload" className="flex flex-col items-center cursor-pointer">
                          <FileUp size={40} className="text-gray-400 mb-4" />
                          <p className="text-lg font-medium">{fileSelected ? fileName : 'Choose file or drag and drop'}</p>
                          <p className="text-sm text-muted-foreground mt-2">
                            PDF, FHIR (JSON, XML) up to 10MB
                          </p>
                        </label>
                      </div>
                    </div>
                    
                    <Alert className="bg-amber-50">
                      <AlertCircle className="h-4 w-4 text-amber-600" />
                      <AlertTitle className="text-amber-800">Privacy Notice</AlertTitle>
                      <AlertDescription className="text-amber-700">
                        Your medical records are processed securely. We do not store your files after analysis.
                      </AlertDescription>
                    </Alert>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-medical-600 hover:bg-medical-700"
                      disabled={!fileSelected}
                    >
                      Upload and Analyze
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="space-y-8 animate-fadeIn">
            <Card>
              <CardHeader>
                <CardTitle>AI-Powered Risk Assessment Results</CardTitle>
                <CardDescription>
                  {assessmentResult?.isBalanced 
                    ? "Great news! Your lifestyle appears to be well-balanced."
                    : "Based on your health information, here's your personalized risk analysis."
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                {assessmentResult?.isBalanced ? (
                  <div className="text-center py-8">
                    <div className="mb-6">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <AlertCircle className="w-8 h-8 text-green-600" />
                      </div>
                      <h3 className="text-xl font-semibold text-green-800 mb-2">
                        Your lifestyle is quite balanced!
                      </h3>
                      <p className="text-green-700">
                        There is no specific risk of contracting a particular disease at this time.
                      </p>
                    </div>
                    
                    <div className="bg-green-50 p-6 rounded-lg">
                      <h4 className="font-medium mb-3">Continue Your Healthy Habits</h4>
                      <ul className="space-y-2 text-sm text-green-800">
                        {assessmentResult.measures.map((measure, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <div className="rounded-full bg-green-200 text-green-800 w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">
                              ✓
                            </div>
                            <span>{measure}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : assessmentResult ? (
                  <div className="space-y-6">
                    <Card className="overflow-hidden">
                      <div className="p-6">
                        <div className="flex justify-between items-center mb-4">
                          <div className="space-y-1">
                            <h4 className="font-semibold text-lg">{assessmentResult.disease}</h4>
                            <Badge variant="outline" className={getSeverityColor(assessmentResult.severity)}>
                              {assessmentResult.severity.charAt(0).toUpperCase() + assessmentResult.severity.slice(1)} Risk
                            </Badge>
                          </div>
                          <div className="text-right">
                            <span className="text-2xl font-bold">{assessmentResult.probability}%</span>
                            <p className="text-xs text-muted-foreground">Risk Probability</p>
                          </div>
                        </div>
                        
                        <Progress value={assessmentResult.probability} className="h-2 mb-4" />
                        
                        <div className="space-y-3">
                          <h5 className="text-sm font-medium">Recommended Prevention Measures</h5>
                          <ul className="space-y-2">
                            {assessmentResult.measures.map((measure, index) => (
                              <li key={index} className="text-sm flex items-start gap-2">
                                <div className="rounded-full bg-medical-200 text-medical-800 w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">
                                  {index + 1}
                                </div>
                                <span>{measure}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </Card>
                  </div>
                ) : null}
              </CardContent>
            </Card>
            
            <div className="flex justify-center">
              <Button 
                variant="outline" 
                onClick={() => {
                  setFormSubmitted(false);
                  setAssessmentResult(null);
                  setAge('');
                  setHeight('');
                  setWeight('');
                  setFamilyHistory(false);
                  setSmoking(false);
                  setExerciseLevel([3]);
                }}
                className="border-medical-300 text-medical-700 hover:bg-medical-50"
              >
                <FilePlus size={18} className="mr-2" />
                Start New Assessment
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default RiskAssessmentPage;
