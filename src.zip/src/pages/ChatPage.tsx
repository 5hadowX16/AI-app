
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import Layout from '@/components/Layout';
import { Send, Bot, RefreshCw, CheckCircle, XCircle, MessageSquare, Coffee, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Message, processUserMessage, CommandMode, API_ENDPOINT } from '@/utils/chatAI';

const ChatPage: React.FC = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, type: 'ai', text: 'Hey! I\'m GyattGPT, your health buddy! How can I help you today?' },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [retryMessage, setRetryMessage] = useState<Message | null>(null);
  const [lastUserMessage, setLastUserMessage] = useState<string>('');
  const [commandMode, setCommandMode] = useState<CommandMode>('/q');
  const [showYesNoButtons, setShowYesNoButtons] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    console.log("Current command mode:", commandMode);

    // Add user message
    const userMessage = { id: messages.length + 1, type: 'user' as const, text: input };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInput('');
    setIsTyping(true);
    setRetryMessage(null);
    setLastUserMessage(input);
    setShowYesNoButtons(false);

    try {
      // Process user message and generate AI response
      console.log("Processing user message:", input, "with mode:", commandMode);
      const response = await processUserMessage(input, commandMode);
      console.log("Response received:", response);
      
      // Check if this response requires Yes/No confirmation
      const requiresConfirmation = response.includes("(Say yes or no!)");
      setShowYesNoButtons(requiresConfirmation);
      
      const aiMessage = { id: messages.length + 2, type: 'ai' as const, text: response };
      setMessages((prevMessages) => [...prevMessages, aiMessage]);
    } catch (error) {
      console.error("Error processing message:", error);
      toast({
        title: "Error",
        description: "Failed to generate a response. Please try again.",
        variant: "destructive"
      });
      
      // Save the failed message for potential retry
      setRetryMessage(userMessage);
      
      // Fallback response
      const errorMessage = { 
        id: messages.length + 2, 
        type: 'ai' as const, 
        text: "I'm sorry, but I'm having trouble processing your request right now. Please ensure the Flask server is running at " + API_ENDPOINT 
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleYesNoResponse = async (response: 'yes' | 'no') => {
    // Add user's response as a new message
    const responseText = response === 'yes' ? 'Yes' : 'No';
    const userMessage = { id: messages.length + 1, type: 'user' as const, text: responseText };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    
    setIsTyping(true);
    setShowYesNoButtons(false);
    
    try {
      console.log("Sending confirmation:", response, "with /confirm command");
      // Send confirmation to backend with /confirm command
      const aiResponse = await processUserMessage(response, '/confirm');
      console.log("Confirmation response received:", aiResponse);
      
      const aiMessage = { id: userMessage.id + 1, type: 'ai' as const, text: aiResponse };
      setMessages((prevMessages) => [...prevMessages, aiMessage]);
      
      // Check if new response requires confirmation
      const requiresConfirmation = aiResponse.includes("(Say yes or no!)");
      setShowYesNoButtons(requiresConfirmation);
    } catch (error) {
      console.error("Error processing confirmation:", error);
      toast({
        title: "Error",
        description: "Failed to process your response. Please try again.",
        variant: "destructive"
      });
      
      const errorMessage = { 
        id: userMessage.id + 1, 
        type: 'ai' as const, 
        text: "I'm having trouble processing your response. Please try again later." 
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };
  
  const handleRetry = async () => {
    if (!lastUserMessage) return;
    
    setIsTyping(true);
    
    try {
      const response = await processUserMessage(lastUserMessage, commandMode);
      const aiMessage = { id: messages.length + 1, type: 'ai' as const, text: response };
      setMessages((prevMessages) => [...prevMessages, aiMessage]);
      
      // Check if response requires confirmation
      const requiresConfirmation = response.includes("(Say yes or no!)");
      setShowYesNoButtons(requiresConfirmation);
    } catch (error) {
      console.error("Error retrying message:", error);
      toast({
        title: "Error",
        description: "Failed to generate a response. Please try again.",
        variant: "destructive"
      });
      
      const errorMessage = { 
        id: messages.length + 1, 
        type: 'ai' as const, 
        text: "I'm still having trouble processing your request. Please try again later or rephrase your question." 
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const modeLabels = {
    '/q': 'Question Mode',
    '/g': 'Greeting Mode',
    '/c': 'Casual Mode'
  };

  const modeIcons = {
    '/q': <BookOpen size={16} />,
    '/g': <MessageSquare size={16} />,
    '/c': <Coffee size={16} />
  };

  return (
    <Layout>
      <div className="flex flex-col h-[calc(100vh-8rem)] max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Bot className="text-medical-600" size={28} />
          <h1 className="text-3xl font-bold">Chat with GyattGPT</h1>
        </div>
        
        <Card className="flex-1 overflow-hidden flex flex-col p-4 mb-4 border border-medical-100">
          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            <div className="flex flex-col">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`chat-bubble ${message.type === 'user' ? 'user' : 'ai'} whitespace-pre-line`}
                >
                  {message.text}
                  {message.type === 'ai' && 
                   message.text.includes("Error") && (
                    <Button 
                      onClick={handleRetry} 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 flex items-center gap-1"
                      disabled={isTyping}
                    >
                      <RefreshCw size={14} className={isTyping ? "animate-spin" : ""} />
                      Retry
                    </Button>
                  )}
                </div>
              ))}
              {isTyping && (
                <div className="chat-bubble ai">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              )}
              {showYesNoButtons && !isTyping && (
                <div className="flex gap-2 mt-2 justify-center">
                  <Button 
                    onClick={() => handleYesNoResponse('yes')} 
                    variant="success" 
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <CheckCircle size={14} />
                    Yes
                  </Button>
                  <Button 
                    onClick={() => handleYesNoResponse('no')} 
                    variant="outline" 
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <XCircle size={14} />
                    No
                  </Button>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <form onSubmit={handleSubmit} className="pt-4">
            <div className="flex gap-2 mb-2">
              <Button 
                type="button"
                variant={commandMode === '/q' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCommandMode('/q')}
                className="flex-1"
              >
                {modeIcons['/q']} Question Mode
              </Button>
              <Button 
                type="button"
                variant={commandMode === '/g' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCommandMode('/g')}
                className="flex-1"
              >
                {modeIcons['/g']} Greeting Mode
              </Button>
              <Button 
                type="button"
                variant={commandMode === '/c' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCommandMode('/c')}
                className="flex-1"
              >
                {modeIcons['/c']} Casual Mode
              </Button>
            </div>
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`${modeLabels[commandMode]}: Type your message...`}
                className="flex-1"
                disabled={isTyping || showYesNoButtons}
              />
              <Button 
                type="submit" 
                className="bg-medical-600 hover:bg-medical-700"
                disabled={isTyping || !input.trim() || showYesNoButtons}
              >
                <Send size={18} />
              </Button>
            </div>
          </form>
        </Card>
        
        <div className="text-sm text-muted-foreground text-center">
          <p>GyattGPT is an AI assistant and not a substitute for professional medical advice.</p>
          <p className="text-xs mt-1 opacity-70">Mode: {modeLabels[commandMode]} | Connected to: {API_ENDPOINT}</p>
        </div>
      </div>
    </Layout>
  );
};

export default ChatPage;
