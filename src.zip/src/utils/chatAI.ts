// Interface for a message in the chat
export interface Message {
  id: number;
  type: 'user' | 'ai';
  text: string;
}

// API endpoint for the Flask server
export const API_ENDPOINT = "http://10.2.0.2:5000";

// Command modes
export type CommandMode = '/q' | '/g' | '/c' | '/confirm';

// Process user message and generate AI response
export async function processUserMessage(userMessage: string, mode: CommandMode = '/q'): Promise<string> {
  try {
    console.log(`Sending request to Flask API with mode ${mode}:`, userMessage);
    
    // Make a request to the Flask API
    const response = await fetch(`${API_ENDPOINT}/ask`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        command: mode,
        text: userMessage
      })
    });
    
    if (!response.ok) {
      throw new Error(`API responded with status ${response.status}`);
    }
    
    const data = await response.json();
    console.log("API response:", data);
    
    // Simply return the answer without any prefix filtering
    return data.answer || "No response from API";
  } catch (error) {
    console.error("Error calling Flask API:", error);
    return "Error: Could not connect to the AI backend. Please ensure the Flask server is running at " + API_ENDPOINT;
  }
}

// Function to handle typo suggestion acceptance
export async function acceptTypoSuggestion(suggestion: string): Promise<string> {
  return processUserMessage(suggestion);
}
