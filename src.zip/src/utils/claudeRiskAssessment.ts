
export interface HealthData {
  age: string;
  height: string;
  weight: string;
  familyHistory: boolean;
  smoking: boolean;
  exerciseLevel: number;
}

export interface RiskAssessmentResult {
  disease: string;
  probability: number;
  measures: string[];
  severity: 'high' | 'medium' | 'low';
  isBalanced: boolean;
}

const GEMINI_API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";
const GEMINI_API_KEY = "AIzaSyCCZS2b4-g_n8jcTh2XXLz0na-X_gBkVhA";

export async function analyzeHealthRisk(healthData: HealthData): Promise<RiskAssessmentResult> {
  try {
    // Check if user has a balanced lifestyle (no risk factors)
    const isBalanced = 
      parseInt(healthData.age) < 30 &&
      !healthData.familyHistory &&
      !healthData.smoking &&
      healthData.exerciseLevel >= 4 &&
      calculateBMI(healthData.height, healthData.weight) < 25;

    if (isBalanced) {
      return {
        disease: "No Specific Risk",
        probability: 0,
        measures: [
          "Continue maintaining your healthy lifestyle",
          "Keep up with regular physical activity",
          "Maintain a balanced diet",
          "Regular health check-ups for prevention"
        ],
        severity: 'low',
        isBalanced: true
      };
    }

    // Construct the prompt for Gemini
    const smokingStatus = healthData.smoking ? "do" : "don't";
    const familyHistoryText = healthData.familyHistory ? "I have a family history of Diabetes and heart diseases in general." : "I don't have any significant family history of chronic diseases.";
    
    const prompt = `I am ${healthData.age} years old with a height of ${healthData.height} cm and a weight of ${healthData.weight} kg. ${familyHistoryText} I ${smokingStatus} smoke and my physical activity would be rated as ${healthData.exerciseLevel}/5. 

Please analyze my risk for ALL of these lifestyle-related diseases:
1. Type 2 Diabetes
2. Heart Disease (Cardiovascular Disease)
3. Stroke
4. Lung Cancer
5. Hypertension (High Blood Pressure)
6. Obesity-related complications
7. Osteoporosis
8. Chronic Kidney Disease

After analyzing ALL these diseases, identify which ONE has the HIGHEST risk probability based on my profile. Consider my age, BMI, family history, smoking status, and exercise level.

Respond in this EXACT format:
DISEASE: [name of the single disease with highest risk]
PROBABILITY: [percentage number only, like 65]
MEASURES: [prevention measure 1] | [prevention measure 2] | [prevention measure 3] | [prevention measure 4]

Choose only ONE disease - the one with the highest calculated risk for my specific profile.`;

    console.log("Sending health data to Gemini:", prompt);

    const response = await fetch(`${GEMINI_API_ENDPOINT}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }]
      })
    });

    if (!response.ok) {
      throw new Error(`Gemini API responded with status ${response.status}`);
    }

    const data = await response.json();
    console.log("Gemini response:", data);

    // Parse Gemini's response
    const geminiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    
    return parseGeminiResponse(geminiResponse);
  } catch (error) {
    console.error("Error analyzing health risk:", error);
    throw new Error("Failed to analyze health risk. Please try again.");
  }
}

function calculateBMI(height: string, weight: string): number {
  const heightInMeters = parseInt(height) / 100;
  const weightInKg = parseInt(weight);
  return weightInKg / (heightInMeters * heightInMeters);
}

function parseGeminiResponse(response: string): RiskAssessmentResult {
  console.log("Parsing Gemini response:", response);
  
  // Try to parse the structured format first
  const diseaseMatch = response.match(/DISEASE:\s*(.+?)(?:\n|$)/i);
  const probabilityMatch = response.match(/PROBABILITY:\s*(\d+)/i);
  const measuresMatch = response.match(/MEASURES:\s*(.+?)(?:\n|$)/i);
  
  let disease = "General Health Risk";
  let probability = 50;
  let measures: string[] = [];
  
  if (diseaseMatch) {
    disease = diseaseMatch[1].trim();
  } else {
    // Fallback parsing
    const fallbackDiseaseMatch = response.match(/(?:risk.*?of|likely.*?to.*?develop|prone.*?to)\s+([^.]+?)(?:\s+is|\s+at|\.|,)/i);
    if (fallbackDiseaseMatch) {
      disease = fallbackDiseaseMatch[1].trim();
    }
  }
  
  if (probabilityMatch) {
    probability = parseInt(probabilityMatch[1]);
  } else {
    // Fallback percentage parsing
    const fallbackPercentMatch = response.match(/(\d+)%/);
    if (fallbackPercentMatch) {
      probability = parseInt(fallbackPercentMatch[1]);
    }
  }
  
  if (measuresMatch) {
    measures = measuresMatch[1].split('|').map(m => m.trim()).filter(m => m.length > 0);
  } else {
    // Fallback measures extraction
    measures = extractPreventionMeasures(response);
  }

  // Clean up the disease name
  disease = disease.replace(/\b(disease|cancer|diabetes)\b/gi, (match) => 
    match.charAt(0).toUpperCase() + match.slice(1).toLowerCase()
  );
  
  // Determine severity based on probability
  let severity: 'high' | 'medium' | 'low' = 'medium';
  if (probability >= 70) {
    severity = 'high';
  } else if (probability < 40) {
    severity = 'low';
  }

  // Ensure we have at least some measures
  if (measures.length === 0) {
    measures = [
      "Maintain a healthy diet rich in fruits and vegetables",
      "Engage in regular physical activity for at least 150 minutes per week",
      "Avoid smoking and limit alcohol consumption",
      "Schedule regular health check-ups with your healthcare provider"
    ];
  }

  return {
    disease,
    probability,
    measures: measures.slice(0, 4), // Limit to 4 measures
    severity,
    isBalanced: false
  };
}

function extractPreventionMeasures(response: string): string[] {
  const measures: string[] = [];
  
  // Look for common prevention-related keywords and extract surrounding text
  const preventionKeywords = [
    'prevent', 'avoid', 'reduce', 'maintain', 'exercise', 'diet', 'quit smoking',
    'regular checkups', 'healthy weight', 'physical activity', 'nutrition'
  ];
  
  // Split response into sentences and look for prevention advice
  const sentences = response.split(/[.!?]+/).filter(s => s.trim().length > 10);
  
  sentences.forEach(sentence => {
    const lowerSentence = sentence.toLowerCase();
    if (preventionKeywords.some(keyword => lowerSentence.includes(keyword))) {
      const cleanSentence = sentence.trim();
      if (cleanSentence && !measures.includes(cleanSentence)) {
        measures.push(cleanSentence);
      }
    }
  });

  return measures.slice(0, 4); // Limit to 4 measures
}
