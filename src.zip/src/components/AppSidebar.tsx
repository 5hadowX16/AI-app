
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import { Home, Heart, AlertCircle, Search, MessageSquare } from 'lucide-react';

const AppSidebar: React.FC = () => {
  const location = useLocation();

  const menuItems = [
    {
      title: 'Home',
      path: '/',
      icon: Home,
    },
    {
      title: 'Chat',
      path: '/chat',
      icon: MessageSquare,
    },
    {
      title: 'Risk Assessment',
      path: '/risk-assessment',
      icon: Heart,
    },
    {
      title: 'Disease Information',
      path: '/disease-info',
      icon: Search,
    },
    {
      title: 'WHO Headlines',
      path: '/who-headlines',
      icon: AlertCircle,
    },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center space-x-2">
          <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-medical-700 to-medical-500">
            GyattGPT
          </span>
          <SidebarTrigger className="ml-auto lg:hidden" />
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton
                    asChild
                    className={location.pathname === item.path ? 'bg-medical-100 text-medical-800' : ''}
                  >
                    <Link to={item.path} className="flex items-center gap-3">
                      <item.icon size={20} />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="text-xs text-muted-foreground">
          © 2025 GyattGPT Health AI
        </div>
      </SidebarFooter>
    </Sidebar>
  );
};

export default AppSidebar;
